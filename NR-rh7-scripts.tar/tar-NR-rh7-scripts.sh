#!/bin/bash

rm -f ./NR-rh7-scripts.tar

tar cf NR-rh7-scripts.tar ./*.sh

rm -f ./*.sh
